﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Programme: Calcul de CRC sur un numéro de carte de crédit
// Auteur:    X. Carrel
// Date:      Mars 2013

namespace Debugger__CRC_
{
    public partial class frmCRC : Form
    {
        const int NbChiffresBase = 18;    // Le nombre de chiffres dans le numéro sans CRC
        long CRCVal; // CRC (cumul) - C'est pas ici qu'il faut l'initialiser à 0

        public frmCRC()
        {
            InitializeComponent();
        }

        private long CRC(string Donnée)
        // Méthode qui calcule le CRC d'une donnée.
        {
            int     NbChiffres = 0; // Pour compter le nombre de chiffres dans le numéro fourni
            CRCVal = 0; // C'est dans cette méthode qu'il faut initialiser à 0
            // Parcourir la donnée
            for (int i = 0; i < Donnée.Length; i++)
            {
                char c = Donnée[i];
                if ((c >= '0') && (c <= '9')) // C'est un chiffre - Il faut mettre >= et <=
                {
                    NbChiffres++;
                    CRCVal = CRCVal + ((int)c - (int)'0');
                    //ça ne doit pas dépasser 99
                    if (CRCVal >= 100) // On ne peut pas dépasser 100 parce qu'on n'a que deux chiffres pour le CRC
                        CRCVal = CRCVal - 100;
                }
            }
            if (NbChiffres != NbChiffresBase)
            {
                MessageBox.Show(string.Format("Erreur: un numéro de carte doit contenir {0} chiffres (sans le CRC)",NbChiffresBase));
                return -1;
            }
            return CRCVal;
        }

        private void cmdCheckCRC_Click(object sender, EventArgs e)
        {
            string Num = txtData.Text;

            if (Num == "")
            {
                MessageBox.Show("Introduisez un numéro de carte SVP");
                return;
            }

            long CRCVal;

            if (rbtCalcul.Checked) // On cherche à calculer un CRC
            {
                CRCVal = CRC(Num); // Calcul du CRC
                if (CRCVal >= 0)
                    MessageBox.Show("Le CRC vaut: " + CRCVal.ToString());
            }
            else // On vérifie un numéro complet
            {
                int CRCIntro = 10 * ((int)Num[Num.Length - 2] - (int)'0') + ((int)Num[Num.Length - 1] - (int)'0'); // Le CRC inclus dans le numéro (deux derniers chiffres)
                Num = Num.Substring(0, Num.Length - 2); // On enlève les deux derniers chiffres
                CRCVal = CRC(Num); // et on calcule le CRC

                if (CRCIntro == CRCVal)
                    MessageBox.Show("Le numéro est valide");
                else
                    MessageBox.Show("Le numéro n'est pas valide");
            }
        }

    }
}
